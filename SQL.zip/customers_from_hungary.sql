
SELECT name FROM customers WHERE country='Hungary';