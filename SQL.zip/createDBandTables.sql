CREATE TABLE customers (
id int PRIMARY KEY NOT NULL,
name varchar(100),
country varchar(100),
city varchar(100)
);
CREATE TABLE orders (
id int PRIMARY KEY NOT NULL,
total decimal,
order_date datetime,
customer_id int
);
SET ANSI_WARNINGS  OFF;
INSERT INTO customers (id, name, country, city)
VALUES 
(1, 'Olga', 'Belarus', 'Jillianborough'),
(2, 'Maria Lebsack DDS', 'Czechia',	'Brno'),
(3,	'Gloria Hyatt',	'Hungary',	'Debrecen'),
(4,	'Clara Spinka',	'Panama',	'Gunnerburgh'),
(5,	'Lonnie Stamm I',	'Hungary',	'Debrecen'),
(6,	'Pat Glover',	'Ukraine',	'West Issac'),
(7,	'Stacy Doyle Jr.',	'Czechia',	'Brno'),
(8,	'Lester Wyman',	'Burundi',	'Pearlineland'),
(9,	'Tyler Marquardt','Argentina','New Haley'),
(10,'Mrs. Carrie Powlowski','Czechia','Prague');
SET ANSI_WARNINGS ON;

SET ANSI_WARNINGS  OFF;
INSERT INTO orders (id, total, order_date, customer_id)
VALUES 
(1,	959.1,	'2021-01-22T00:28:53.986Z',	100),
(2,	703.6,	'2021-01-22T09:23:59.829Z',	89),
(3,	1374.1,	'2021-01-24T13:52:07.161Z',	87),
(4,	1385,	'2021-01-22T03:40:41.063Z',	20),
(5,	747.7,	'2021-01-20T21:52:58.248Z',	63),
(6,	517.9,	'2021-01-24T15:38:49.595Z',	89),
(7,	830.4,	'2021-01-20T07:29:12.267Z',	95),
(8,	967.3,	'2021-01-20T12:53:27.423Z',	84),
(9,	931.2,	'2021-01-21T07:33:14.933Z',	89),
(10,	1141.2,	'2021-01-19T20:56:49.386Z',	6);
SET ANSI_WARNINGS ON;


