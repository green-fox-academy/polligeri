
#!/bin/bash

function get_kernel_version() {
uname -a
}

function get_free_space(){
free
df -h
}

function get_total_mem(){
echo Total memory in KByte:
grep MemTotal /proc/meminfo | awk '{print $2}'
}

get_kernel_version
get_free_space
get_total_mem
